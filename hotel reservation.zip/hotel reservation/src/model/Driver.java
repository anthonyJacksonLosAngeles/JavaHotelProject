package model;

public class Driver {
    public static void main(String[] args) {
        try {
            // Create a Customer object with a valid email
            Customer customer1 = new Customer("first", "second", "j@domain.com");
            // Print the Customer object
            System.out.println(customer1);

            // Create a Customer object with an invalid email
            Customer customer2 = new Customer("first", "second", "email");
            // Print the Customer object
            System.out.println(customer2);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }
    }
}