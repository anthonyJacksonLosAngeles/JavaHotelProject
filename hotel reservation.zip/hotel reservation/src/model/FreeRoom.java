package model;

public class FreeRoom extends Room {

    // Constructor
    public FreeRoom(String roomNumber, RoomType roomType) {
        super(roomNumber, 0.0, roomType, true); // Setting roomPrice to 0 and isFree to true
    }

    // Override the toString() method for better description
    @Override
    public String toString() {
        return "Room Number: " + getRoomNumber() + ", Price: Free, Type: " + getRoomType() + ", Free: Yes";
    }
}
