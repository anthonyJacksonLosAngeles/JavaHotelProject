package model;

public class Room implements IRoom {
    private String roomNumber;
    private Double roomPrice;
    private RoomType roomType;
    private boolean isFree;

    // Constructor
    public Room(String roomNumber, Double roomPrice, RoomType roomType, boolean isFree) {
        this.roomNumber = roomNumber;
        this.roomPrice = roomPrice;
        this.roomType = roomType;
        this.isFree = isFree;
    }



    // Implementing the methods from IROOM
    public String getRoomNumber() {
        return roomNumber;
    }

    public Double getRoomPrice() {
        return roomPrice;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public boolean isFree() {
        return isFree;
    }

    // Override the toString() method for better description
    @Override
    public String toString() {
        return "Room Number: " + roomNumber + ", Price: " + roomPrice + ", Type: " + roomType + ", Free: " + (isFree ? "Yes" : "No");
    }
}
