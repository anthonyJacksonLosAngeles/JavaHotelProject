package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

// Define the ReservationService class
public class ReservationService {
    // Static reference to the single instance of ReservationService
    private static ReservationService instance = null;

    // Map to store rooms by their room number
    private Map<String, IRoom> roomMap;
    // Set to store reservations
    private Set<Reservation> reservations;

    // Private constructor to prevent instantiation
    private ReservationService() {
        roomMap = new HashMap<String, IRoom>();
        reservations = new HashSet<Reservation>();
    }

    // Public method to provide access to the single instance
    public static ReservationService getInstance() {
        if (instance == null) {
            instance = new ReservationService();
        }
        return instance;
    }

    // Method to add a room
    public void addRoom(IRoom room) {
        roomMap.put(room.getRoomNumber(), room);
    }

    // Method to get a room by room number
    public IRoom getARoom(String roomId) {
        return roomMap.get(roomId);
    }

    // Method to reserve a room
    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }

    // Method to find available rooms for given dates
    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        Collection<IRoom> availableRooms = new ArrayList<IRoom>(roomMap.values());
        for (Reservation reservation : reservations) {
            if (!(checkOutDate.before(reservation.getCheckInDate()) || checkInDate.after(reservation.getCheckOutDate()))) {
                availableRooms.remove(reservation.getRoom());
            }
        }
        return availableRooms;
    }

    // Method to get all rooms
    public Collection<IRoom> getAllRooms() {
        return roomMap.values();
    }

    // Method to get reservations of a customer
    public Collection<Reservation> getCustomersReservation(Customer customer) {
        Collection<Reservation> customerReservations = new ArrayList<Reservation>();
        for (Reservation reservation : reservations) {
            if (reservation.getCustomer().equals(customer)) {
                customerReservations.add(reservation);
            }
        }
        return customerReservations;
    }

    // Method to print all reservations
    public void printAllReservation() {
        for (Reservation reservation : reservations) {
            System.out.println(reservation);
        }
    }
}

