package service;

import model.Customer;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

// Define the CustomerService class
public class CustomerService {
    // Static reference to the single instance of CustomerService
    private static CustomerService instance = null;

    // Map to store customers by their email
    private Map<String, Customer> customerMap;

    // Private constructor to prevent instantiation
    private CustomerService() {
        customerMap = new HashMap<String, Customer>();
    }

    // Public method to provide access to the single instance
    public static CustomerService getInstance() {
        if (instance == null) {
            instance = new CustomerService();
        }
        return instance;
    }

    // Method to add a customer
    public void addCustomer(String email, String firstName, String lastName) {
        Customer customer = new Customer(firstName, lastName, email);
        customerMap.put(email, customer);
    }

    // Method to get all customers
    public Collection<Customer> getAllCustomers() {
        return customerMap.values();
    }

    ////deletes this if something messes up
    public Customer getCustomer(String email) {
        return null;
    }
}