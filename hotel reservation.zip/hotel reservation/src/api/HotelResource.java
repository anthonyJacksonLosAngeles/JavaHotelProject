package api;

import model.Customer;
import service.CustomerService;
import model.IRoom;
import model.Reservation;
import service.ReservationService;

import java.util.Collection;
import java.util.Date;

public class HotelResource {
    // Static reference to the single instance of HotelResource
    private static HotelResource instance = null;

    // Private constructor to prevent instantiation
    private HotelResource() {}

    // Public method to provide access to the single instance
    public static HotelResource getInstance() {
        if (instance == null) {
            instance = new HotelResource();
        }
        return instance;
    }

    // Method to get a customer by email
    public Customer getCustomer(String email) {
        return CustomerService.getInstance().getCustomer(email);
    }

    // Method to create a new customer
    public void createACustomer(String email, String firstName, String lastName) {
        CustomerService.getInstance().addCustomer(email, firstName, lastName);
    }

    // Method to get a room by room number
    public IRoom getRoom(String roomNumber) {
        return ReservationService.getInstance().getARoom(roomNumber);
    }

    // Method to book a room
    public Reservation bookARoom(String customerEmail, IRoom room, Date checkInDate, Date checkOutDate) {
        Customer customer = getCustomer(customerEmail);
        if (customer == null) {
            throw new IllegalArgumentException("Customer with email " + customerEmail + " does not exist.");
        }
        return ReservationService.getInstance().reserveARoom(customer, room, checkInDate, checkOutDate);
    }

    // Method to get reservations of a customer
    public Collection<Reservation> getCustomersReservations(String customerEmail) {
        Customer customer = getCustomer(customerEmail);
        if (customer == null) {
            throw new IllegalArgumentException("Customer with email " + customerEmail + " does not exist.");
        }
        return ReservationService.getInstance().getCustomersReservation(customer);
    }

    // Method to find available rooms for given dates
    public Collection<IRoom> findARoom(Date checkIn, Date checkOut) {
        return ReservationService.getInstance().findRooms(checkIn, checkOut);
    }
}
