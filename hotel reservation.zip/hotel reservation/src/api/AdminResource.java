package api;


import model.Customer;
import model.IRoom;
import service.CustomerService;
import service.ReservationService;

import java.util.Collection;
import java.util.List;

public class AdminResource {
    // Static reference to the single instance of AdminResource
    private static AdminResource instance = null;

    // Private constructor to prevent instantiation
    private AdminResource() {}

    // Public method to provide access to the single instance
    public static AdminResource getInstance() {
        if (instance == null) {
            instance = new AdminResource();
        }
        return instance;
    }

    // get a customer by email
    public Customer getCustomer(String email) {
        return CustomerService.getInstance().getCustomer(email);
    }

    //  add rooms
    public void addRoom(List<IRoom> rooms) {
        for (IRoom room : rooms) {
            ReservationService.getInstance().addRoom(room);
        }
    }

    // see get all rooms
    public Collection<IRoom> getAllRooms() {
        return ReservationService.getInstance().getAllRooms();
    }

    public Collection<Customer> getAllCustomers() { return
        CustomerService.getInstance().getAllCustomers();
    }


    // display all reservations
    public void displayAllReservations() {
        ReservationService.getInstance().printAllReservation();
    }
}
